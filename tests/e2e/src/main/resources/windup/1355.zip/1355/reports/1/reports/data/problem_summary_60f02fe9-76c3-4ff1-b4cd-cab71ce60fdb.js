MIGRATION_ISSUES_DETAILS["60f02fe9-76c3-4ff1-b4cd-cab71ce60fdb"] = [
{description: "<p>The application embedds an Ehcache library. <\/p><p>Cloud readiness issue as potential state information that is not persisted to a backing service.<\/p>", ruleID: "DiscoverEmbeddedCacheEhcacheLibraryRuleProvider_1", issueName: "Caching - Ehcache embedded library",
problemSummaryID: "60f02fe9-76c3-4ff1-b4cd-cab71ce60fdb", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/ehcache-core-2.5.1.jar", oc:"1"},
], resourceLinks: [
]},
];