MIGRATION_ISSUES_DETAILS["01a4f10b-5cd1-4a8a-b0f0-37d7e1da8180"] = [
{description: "<p>Maven Project Object Model (POM) File<\/p>", ruleID: "DiscoverMavenProjectsRuleProvider_1", issueName: "Maven POM (pom.xml)",
problemSummaryID: "01a4f10b-5cd1-4a8a-b0f0-37d7e1da8180", files: [
{l:"<a class='' href='pom_xml.177.html?project=6112000'>META-INF/maven/org.ktest.javaee.study.ejb3-in-action/chapter3-ear/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.178.html?project=6112000'>META-INF/maven/org.ktest.javaee.study.ejb3-in-action/chapter3-ejb/pom.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];