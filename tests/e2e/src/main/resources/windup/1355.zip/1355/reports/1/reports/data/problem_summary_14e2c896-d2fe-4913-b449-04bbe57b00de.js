MIGRATION_ISSUES_DETAILS["14e2c896-d2fe-4913-b449-04bbe57b00de"] = [
{description: "<p><strong>Hard-coded IP: 2.5.4.6<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.10<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.11<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.12<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.3<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.5<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.7<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.8<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.4<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.42<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.43<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.44<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.45<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "14e2c896-d2fe-4913-b449-04bbe57b00de", files: [
{l:"<a class='' href='PdfPKCS7_java.html?project=6456320'>com.lowagie.text.pdf.PdfPKCS7<\/a>", oc:"1"},
], resourceLinks: [
]},
];