MIGRATION_ISSUES_DETAILS["b5ceb7e3-f6c2-437d-b8fb-070f553fd370"] = [
{description: "<p>The application embeds the Spring framework.<\/p>", ruleID: "embedded-framework-02100", issueName: "Embedded framework - Spring",
problemSummaryID: "b5ceb7e3-f6c2-437d-b8fb-070f553fd370", files: [
{l:"spring-core-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-expression-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-aop-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-context-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-beans-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-asm-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/spring-core-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/spring-expression-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/spring-aop-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/spring-context-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/spring-beans-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/spring-asm-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/spring-core-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/spring-expression-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/spring-aop-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/spring-context-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/spring-beans-3.0.5.RELEASE.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/spring-asm-3.0.5.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];