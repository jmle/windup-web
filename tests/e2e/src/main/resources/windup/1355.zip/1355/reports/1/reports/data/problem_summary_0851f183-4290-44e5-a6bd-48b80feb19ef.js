MIGRATION_ISSUES_DETAILS["0851f183-4290-44e5-a6bd-48b80feb19ef"] = [
{description: "<p>The JNDI automatically reads the application resource files from all components in the applications\' classpaths. The JNDI then makes the properties from these files available to the service providers.<\/p><p>Please ensure the property values listed in this file are available to JBoss.<\/p>", ruleID: "environment-dependent-calls-03500", issueName: "JNDI properties file",
problemSummaryID: "0851f183-4290-44e5-a6bd-48b80feb19ef", files: [
{l:"<a class='' href='jndi_properties.html?project=6211328'>jndi.properties<\/a>", oc:"1"},
], resourceLinks: [
]},
];