MIGRATION_ISSUES_DETAILS["afb32ee4-b2da-4686-a56f-da5ef7c10945"] = [
{description: "<p>The application embedds an Ehcache library. <\/p><p>Cloud readiness issue as potential state information that is not persisted to a backing service.<\/p>", ruleID: "DiscoverEmbeddedCacheEhcacheLibraryRuleProvider_1", issueName: "Caching - Ehcache embedded library",
problemSummaryID: "afb32ee4-b2da-4686-a56f-da5ef7c10945", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/ehcache-core-2.5.1.jar", oc:"1"},
], resourceLinks: [
]},
];