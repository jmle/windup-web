MIGRATION_ISSUES_DETAILS["b6174bf1-869c-4063-bc88-051c2b1432c9"] = [
{description: "<p>The application embeds the Apache Axis framework.<\/p>", ruleID: "embedded-framework-01000", issueName: "Embedded framework - Apache Axis",
problemSummaryID: "b6174bf1-869c-4063-bc88-051c2b1432c9", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/axis-jaxrpc-1.4.jar", oc:"1"},
], resourceLinks: [
]},
];