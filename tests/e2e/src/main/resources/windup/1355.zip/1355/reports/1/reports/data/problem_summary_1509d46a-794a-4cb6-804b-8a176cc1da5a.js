MIGRATION_ISSUES_DETAILS["1509d46a-794a-4cb6-804b-8a176cc1da5a"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "1509d46a-794a-4cb6-804b-8a176cc1da5a", files: [
{l:"<a class='' href='web_xml.3.html?project=5838848'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];