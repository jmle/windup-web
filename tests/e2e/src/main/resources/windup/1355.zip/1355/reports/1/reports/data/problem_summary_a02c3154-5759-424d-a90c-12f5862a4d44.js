MIGRATION_ISSUES_DETAILS["a02c3154-5759-424d-a90c-12f5862a4d44"] = [
{description: "<p>The application embeds the Jersey framework.<\/p>", ruleID: "embedded-framework-01300", issueName: "Embedded framework - Jersey",
problemSummaryID: "a02c3154-5759-424d-a90c-12f5862a4d44", files: [
{l:"Cloudental-ear-1.0-SNAPSHOT.ear/Cloudental-cdi.war/WEB-INF/lib/jersey-core-1.13.jar", oc:"1"},
{l:"Cloudental-ear-1.0-SNAPSHOT.ear/Cloudental-cdi.war/WEB-INF/lib/jersey-client-1.13.jar", oc:"1"},
{l:"Cloudental-ear-1.0-SNAPSHOT.ear/Cloudental-cdi.war/WEB-INF/lib/jersey-server-1.13.jar", oc:"1"},
], resourceLinks: [
]},
];