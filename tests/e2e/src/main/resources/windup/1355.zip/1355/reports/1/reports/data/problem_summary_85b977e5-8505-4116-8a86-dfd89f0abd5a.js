MIGRATION_ISSUES_DETAILS["85b977e5-8505-4116-8a86-dfd89f0abd5a"] = [
{description: "<p>This file contains WebSphere proprietary JSP engine configuration.<\/p><p>To migrate to EAP 7, configure it accordingly using the CLI or the web console.<\/p>", ruleID: "eap7-websphere-xml-03500", issueName: "WebSphere JSP engine configuration (ibm-web-ext)",
problemSummaryID: "85b977e5-8505-4116-8a86-dfd89f0abd5a", files: [
{l:"<a class='' href='ibm_web_ext_xml.html?project=6171392'>WEB-INF/ibm-web-ext.xml<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://access.redhat.com/articles/1330673#jspattributes", t:"JSP engine configuration migration to EAP 6"},
]},
];