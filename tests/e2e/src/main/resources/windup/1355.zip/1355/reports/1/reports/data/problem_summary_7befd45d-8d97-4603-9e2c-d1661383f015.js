MIGRATION_ISSUES_DETAILS["7befd45d-8d97-4603-9e2c-d1661383f015"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "7befd45d-8d97-4603-9e2c-d1661383f015", files: [
{l:"<a class='' href='web_xml.7.html?project=6167808'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];