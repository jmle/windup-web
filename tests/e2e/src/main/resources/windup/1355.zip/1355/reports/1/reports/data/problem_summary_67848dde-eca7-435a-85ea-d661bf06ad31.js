MIGRATION_ISSUES_DETAILS["67848dde-eca7-435a-85ea-d661bf06ad31"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "67848dde-eca7-435a-85ea-d661bf06ad31", files: [
{l:"<a class='' href='web_xml.1.html?project=6171392'>WEB-INF/web.xml<\/a>", oc:"1"},
{l:"<a class='' href='web_xml.2.html?project=6211328'>WEB-INF/web.xml<\/a>", oc:"1"},
{l:"<a class='' href='web_xml.3.html?project=5838848'>WEB-INF/web.xml<\/a>", oc:"1"},
{l:"<a class='' href='web_xml.4.html?project=6049792'>WEB-INF/web.xml<\/a>", oc:"1"},
{l:"<a class='' href='web_xml.5.html?project=6456320'>WEB-INF/web.xml<\/a>", oc:"1"},
{l:"<a class='' href='web_xml.6.html?project=6459904'>WEB-INF/web.xml<\/a>", oc:"1"},
{l:"<a class='' href='web_xml.7.html?project=6167808'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];