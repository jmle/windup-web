MIGRATION_ISSUES_DETAILS["8e9d0be0-ed4d-467c-8ca6-e20ef7c96869"] = [
{description: "<p>The application embedds a JDBC library.<\/p>", ruleID: "DiscoverEmbeddedJDBCLibraryRuleProvider_1", issueName: "Embedded library - JDBC",
problemSummaryID: "8e9d0be0-ed4d-467c-8ca6-e20ef7c96869", files: [
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/ojdbc6.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-jdbc-4.0.9.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];