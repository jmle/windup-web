MIGRATION_ISSUES_DETAILS["44559e7b-12a0-48bf-9441-67a2259056ac"] = [
{description: "<p>Maven Project Object Model (POM) File<\/p>", ruleID: "DiscoverMavenProjectsRuleProvider_1", issueName: "Maven POM (pom.xml)",
problemSummaryID: "44559e7b-12a0-48bf-9441-67a2259056ac", files: [
{l:"<a class='' href='pom_xml.47.html?project=6551552'>META-INF/maven/org.hibernate.javax.persistence/hibernate-jpa-2.0-api/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.48.html?project=6551552'>META-INF/maven/org.slf4j/slf4j-api/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.78.html?project=6551552'>META-INF/maven/commons-logging/commons-logging/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.170.html?project=6551552'>META-INF/maven/commons-beanutils/commons-beanutils/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.174.html?project=6551552'>META-INF/maven/org.codehaus.castor/castor/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.176.html?project=6551552'>META-INF/maven/commons-digester/commons-digester/pom.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];