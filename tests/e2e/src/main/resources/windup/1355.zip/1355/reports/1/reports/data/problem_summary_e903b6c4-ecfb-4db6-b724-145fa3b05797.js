MIGRATION_ISSUES_DETAILS["e903b6c4-ecfb-4db6-b724-145fa3b05797"] = [
{description: "<p>The application embeds the AspectJ framework.<\/p>", ruleID: "embedded-framework-02200", issueName: "Embedded framework - AspectJ",
problemSummaryID: "e903b6c4-ecfb-4db6-b724-145fa3b05797", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/aspectjrt-1.5.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/aspectjweaver-1.5.3.jar", oc:"1"},
], resourceLinks: [
]},
];