MIGRATION_ISSUES_DETAILS["605e9b14-4ebe-4531-94ba-2f5e04d9cef8"] = [
{description: "<p>The application embeds a Spring MVC library.<\/p>", ruleID: "mvc-01200", issueName: "Embedded library - Spring MVC",
problemSummaryID: "605e9b14-4ebe-4531-94ba-2f5e04d9cef8", files: [
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-webmvc-4.0.9.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];