MIGRATION_ISSUES_DETAILS["3e5667c8-71c8-4772-b4e1-077f8bfff2bf"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "3e5667c8-71c8-4772-b4e1-077f8bfff2bf", files: [
{l:"<a class='' href='web_xml.5.html?project=6456320'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];