MIGRATION_ISSUES_DETAILS["0f925256-ddb6-4596-ac77-22acc20244c5"] = [
{description: "<p>The application embeds the Spring framework.<\/p>", ruleID: "embedded-framework-02100", issueName: "Embedded framework - Spring",
problemSummaryID: "0f925256-ddb6-4596-ac77-22acc20244c5", files: [
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-xml-2.3.0.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-context-support-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-aop-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-oxm-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-ws-core-2.3.0.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-webmvc-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-jdbc-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-web-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-orm-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-expression-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-context-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-beans-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-tx-4.0.9.RELEASE.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-core-4.0.9.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];