MIGRATION_ISSUES_DETAILS["94837459-5eb8-47d7-a1b4-ce8e5ab6aa08"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "94837459-5eb8-47d7-a1b4-ce8e5ab6aa08", files: [
{l:"<a class='' href='web_xml.4.html?project=6049792'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];