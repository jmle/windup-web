MIGRATION_ISSUES_DETAILS["625ce829-98ad-4eff-9b4d-3fd7af12cafa"] = [
{description: "<p>Enterprise Java Bean XML Descriptor.<\/p>", ruleID: "DiscoverEjbConfigurationXmlRuleProvider_1", issueName: "EJB XML",
problemSummaryID: "625ce829-98ad-4eff-9b4d-3fd7af12cafa", files: [
{l:"<a class='' href='ejb_jar_xml.html?project=6167808'>META-INF/ejb-jar.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];