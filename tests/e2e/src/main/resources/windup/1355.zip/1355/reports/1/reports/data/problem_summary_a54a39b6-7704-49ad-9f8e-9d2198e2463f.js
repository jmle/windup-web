MIGRATION_ISSUES_DETAILS["a54a39b6-7704-49ad-9f8e-9d2198e2463f"] = [
{description: "<p>The application embeds the Hibernate framework.<\/p>", ruleID: "embedded-framework-01500", issueName: "Embedded framework - Hibernate",
problemSummaryID: "a54a39b6-7704-49ad-9f8e-9d2198e2463f", files: [
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/hibernate-commons-annotations-3.2.0.Final.jar", oc:"1"},
{l:"hibernate-jpa-2.0-api-1.0.1.Final.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/hibernate-entitymanager-3.6.10.Final.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/hibernate-core-3.6.10.Final.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/hibernate-jpa-2.0-api-1.0.1.Final.jar", oc:"1"},
], resourceLinks: [
]},
];