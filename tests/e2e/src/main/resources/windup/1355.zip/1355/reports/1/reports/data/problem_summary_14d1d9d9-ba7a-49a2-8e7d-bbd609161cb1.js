MIGRATION_ISSUES_DETAILS["14d1d9d9-ba7a-49a2-8e7d-bbd609161cb1"] = [
{description: "<p>After migration, some of the JMX beans provided by the previous server may not be present anymore. Ensure that the <code>javax.management.ObjectName<\/code> does not need to change for JBoss.<\/p>", ruleID: "environment-dependent-calls-04000", issueName: "JMX MBean object name (javax.management.ObjectName)",
problemSummaryID: "14d1d9d9-ba7a-49a2-8e7d-bbd609161cb1", files: [
{l:"<a class='' href='JMXPlatformImpl_java.html?project=6049792'>org.dozer.jmx.JMXPlatformImpl<\/a>", oc:"2"},
], resourceLinks: [
]},
];