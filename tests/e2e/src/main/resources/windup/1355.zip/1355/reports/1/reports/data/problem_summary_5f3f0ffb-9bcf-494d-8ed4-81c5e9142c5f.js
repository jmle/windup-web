MIGRATION_ISSUES_DETAILS["5f3f0ffb-9bcf-494d-8ed4-81c5e9142c5f"] = [
{description: "<p>The application embedds an Apache Camel library.<\/p>", ruleID: "DiscoverEmbeddedCamelLibraryRuleProvider_1", issueName: "Embedded library - Apache Camel",
problemSummaryID: "5f3f0ffb-9bcf-494d-8ed4-81c5e9142c5f", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-spring-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-test-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-cxf-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-blueprint-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-stream-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-core-xml-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-core-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-test-spring-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-core-osgi-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-cxf-transport-2.10.3.jar", oc:"1"},
], resourceLinks: [
]},
];