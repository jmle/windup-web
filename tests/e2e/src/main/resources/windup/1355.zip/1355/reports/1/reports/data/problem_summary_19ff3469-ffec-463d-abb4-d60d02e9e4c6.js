MIGRATION_ISSUES_DETAILS["19ff3469-ffec-463d-abb4-d60d02e9e4c6"] = [
{description: "<p>The application embeds the Hibernate framework.<\/p>", ruleID: "embedded-framework-01500", issueName: "Embedded framework - Hibernate",
problemSummaryID: "19ff3469-ffec-463d-abb4-d60d02e9e4c6", files: [
{l:"hibernate-jpa-2.0-api-1.0.1.Final.jar", oc:"1"},
], resourceLinks: [
]},
];