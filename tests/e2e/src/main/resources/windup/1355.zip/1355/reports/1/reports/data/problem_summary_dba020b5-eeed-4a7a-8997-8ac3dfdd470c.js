MIGRATION_ISSUES_DETAILS["dba020b5-eeed-4a7a-8997-8ac3dfdd470c"] = [
{description: "<p>This file contains WebSphere proprietary binding configuration.<\/p><p>To migrate to EAP 7+, configure EAP 7+ accordingly using the CLI interface or web console.<\/p>", ruleID: "eap7-websphere-xml-06000", issueName: "WebSphere web application binding (ibm-web-bnd)",
problemSummaryID: "dba020b5-eeed-4a7a-8997-8ac3dfdd470c", files: [
{l:"<a class='' href='ibm_web_bnd_xml.html?project=6171392'>WEB-INF/ibm-web-bnd.xml<\/a>", oc:"1"},
], resourceLinks: [
{h:"http://rjweb002.royalsun.com.br/configDocs/webappbnd/WebAppBinding.html", t:"WebAppBinding javadoc"},
{h:"https://access.redhat.com/documentation/en/red-hat-jboss-enterprise-application-platform/7.0/single/configuration-guide/#configuring_the_web_server_undertow", t:"Configure the EAP 7 Web Server (Undertow)"},
{h:"http://docs.jboss.org/jbossweb/7.0.x/", t:"JBoss Web configuration"},
{h:"http://undertow.io/undertow-docs/undertow-docs-1.3.0/index.html", t:"Undertow documentation"},
{h:"https://access.redhat.com/articles/1330673", t:"Migrate IBM WebSphere Application Server Web Application Extension or Binding Files"},
]},
];