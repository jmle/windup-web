MIGRATION_ISSUES_DETAILS["2496f3b4-71ca-40ce-a3f6-e2077c784753"] = [
{description: "<p>The application embeds the Hibernate framework.<\/p>", ruleID: "embedded-framework-01500", issueName: "Embedded framework - Hibernate",
problemSummaryID: "2496f3b4-71ca-40ce-a3f6-e2077c784753", files: [
{l:"hibernate-jpa-2.0-api-1.0.1.Final.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/hibernate-validator-4.1.0.Final.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/hibernate-jpa-2.0-api-1.0.1.Final.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/hibernate-commons-annotations-4.0.1.Final.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/hibernate-core-4.1.4.Final.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/hibernate-validator-4.1.0.Final.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/hibernate-jpa-2.0-api-1.0.1.Final.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/hibernate-commons-annotations-4.0.1.Final.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/hibernate-core-4.1.4.Final.jar", oc:"1"},
], resourceLinks: [
]},
];