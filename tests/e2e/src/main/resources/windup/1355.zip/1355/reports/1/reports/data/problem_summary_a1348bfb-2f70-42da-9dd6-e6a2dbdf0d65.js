MIGRATION_ISSUES_DETAILS["a1348bfb-2f70-42da-9dd6-e6a2dbdf0d65"] = [
{description: "<p>Use <code>org.hibernate.boot.registry.StandardServiceRegistryBuilder#configure<\/code> instead.<\/p>", ruleID: "hibernate4-00021", issueName: "Hibernate 5 - Deprecated method org.hibernate.cfg.Configuration.configure()",
problemSummaryID: "a1348bfb-2f70-42da-9dd6-e6a2dbdf0d65", files: [
{l:"<a class='' href='DVKAPI_java.html?project=6211328'>dvk.api.DVKAPI<\/a>", oc:"2"},
], resourceLinks: [
{h:"https://github.com/hibernate/hibernate-orm/blob/5.0/migration-guide.adoc#re-purposing-of-configuration", t:"Changes in Configuration for Hibernate 5"},
{h:"https://access.redhat.com/documentation/en/red-hat-jboss-enterprise-application-platform/version-7.0/migration-guide/chapter-4-application-changes#hibernate_and_jpa_migration_changes", t:"Hibernate and JPA migration changes"},
]},
];