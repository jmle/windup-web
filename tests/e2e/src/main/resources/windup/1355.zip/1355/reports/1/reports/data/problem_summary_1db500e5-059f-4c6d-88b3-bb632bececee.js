MIGRATION_ISSUES_DETAILS["1db500e5-059f-4c6d-88b3-bb632bececee"] = [
{description: "<p>The application embedds a JDBC library.<\/p>", ruleID: "DiscoverEmbeddedJDBCLibraryRuleProvider_1", issueName: "Embedded library - JDBC",
problemSummaryID: "1db500e5-059f-4c6d-88b3-bb632bececee", files: [
{l:"arit-ear-0.8.1-SNAPSHOT.ear/arit.war/WEB-INF/lib/arit-jdbc-0.8.1-SNAPSHOT.jar", oc:"1"},
], resourceLinks: [
]},
];