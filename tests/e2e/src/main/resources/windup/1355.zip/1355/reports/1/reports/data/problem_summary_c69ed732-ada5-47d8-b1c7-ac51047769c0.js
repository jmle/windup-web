MIGRATION_ISSUES_DETAILS["c69ed732-ada5-47d8-b1c7-ac51047769c0"] = [
{description: "<p>The application embeds the Jersey framework.<\/p>", ruleID: "embedded-framework-01300", issueName: "Embedded framework - Jersey",
problemSummaryID: "c69ed732-ada5-47d8-b1c7-ac51047769c0", files: [
{l:"Cloudental-ear-1.0-SNAPSHOT.ear/Cloudental-cdi.war/WEB-INF/lib/jersey-core-1.13.jar", oc:"1"},
{l:"Cloudental-ear-1.0-SNAPSHOT.ear/Cloudental-cdi.war/WEB-INF/lib/jersey-client-1.13.jar", oc:"1"},
{l:"Cloudental-ear-1.0-SNAPSHOT.ear/Cloudental-cdi.war/WEB-INF/lib/jersey-server-1.13.jar", oc:"1"},
], resourceLinks: [
]},
];