MIGRATION_ISSUES_DETAILS["5b543065-ea4c-4968-bcf7-5495fe4a881d"] = [
{description: "<p>The application embeds the AspectJ framework.<\/p>", ruleID: "embedded-framework-02200", issueName: "Embedded framework - AspectJ",
problemSummaryID: "5b543065-ea4c-4968-bcf7-5495fe4a881d", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/aspectjrt-1.5.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/aspectjweaver-1.5.3.jar", oc:"1"},
], resourceLinks: [
]},
];