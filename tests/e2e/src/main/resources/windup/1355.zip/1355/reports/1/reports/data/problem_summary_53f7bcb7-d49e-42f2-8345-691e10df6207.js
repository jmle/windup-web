MIGRATION_ISSUES_DETAILS["53f7bcb7-d49e-42f2-8345-691e10df6207"] = [
{description: "<p>Enterprise Java Bean XML Descriptor.<\/p>", ruleID: "DiscoverEjbConfigurationXmlRuleProvider_1", issueName: "EJB XML",
problemSummaryID: "53f7bcb7-d49e-42f2-8345-691e10df6207", files: [
{l:"<a class='' href='ejb_jar_xml.html?project=6167808'>META-INF/ejb-jar.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];