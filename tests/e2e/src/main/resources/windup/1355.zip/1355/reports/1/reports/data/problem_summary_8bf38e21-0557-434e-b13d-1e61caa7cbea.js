MIGRATION_ISSUES_DETAILS["8bf38e21-0557-434e-b13d-1e61caa7cbea"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "8bf38e21-0557-434e-b13d-1e61caa7cbea", files: [
{l:"<a class='' href='web_xml.1.html?project=6171392'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];