MIGRATION_ISSUES_DETAILS["3645ab0e-3313-47ee-a176-0890ba1ea101"] = [
{description: "<p>The <code>org.apache.ws.security.WSPasswordCallback<\/code> class has moved to package <code>org.apache.wss4j.common.ext<\/code>. The application must be changed to reference to the new package.<\/p>", ruleID: "ws-security-00000", issueName: "WS-Security WSPasswordCallback\'s package changed",
problemSummaryID: "3645ab0e-3313-47ee-a176-0890ba1ea101", files: [
{l:"<a class='' href='MyPasswordCallback_java.html?project=6049792'>com.addition.sources.common.interceptor.MyPasswordCallback<\/a>", oc:"1"},
], resourceLinks: [
{h:"https://access.redhat.com/documentation/en-us/red_hat_jboss_enterprise_application_platform/7.0/html-single/migration_guide/#migrate_ws_security_changes", t:"WS-Security Changes"},
]},
];