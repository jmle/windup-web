MIGRATION_ISSUES_DETAILS["5bea4206-ee57-4b32-8f5e-d87a96831276"] = [
{description: "<p>This XML file could not be parsed.<\/p>", ruleID: "DiscoverXmlFilesRuleProvider_5", issueName: "Unparsable XML File",
problemSummaryID: "5bea4206-ee57-4b32-8f5e-d87a96831276", files: [
{l:"<a class='' href='recepcionDeposito_xhtml.html?project=6456320'>recepcionDeposito/recepcionDeposito/recepcionDeposito.xhtml<\/a>", oc:"1"},
], resourceLinks: [
]},
];