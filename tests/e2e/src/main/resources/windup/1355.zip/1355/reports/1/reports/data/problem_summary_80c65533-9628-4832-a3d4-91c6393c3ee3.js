MIGRATION_ISSUES_DETAILS["80c65533-9628-4832-a3d4-91c6393c3ee3"] = [
{description: "<p>The application embedds an Apache Camel library.<\/p>", ruleID: "DiscoverEmbeddedCamelLibraryRuleProvider_1", issueName: "Embedded library - Apache Camel",
problemSummaryID: "80c65533-9628-4832-a3d4-91c6393c3ee3", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-spring-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-test-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-cxf-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-blueprint-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-stream-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-core-xml-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-core-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-test-spring-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-core-osgi-2.10.3.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/camel-cxf-transport-2.10.3.jar", oc:"1"},
], resourceLinks: [
]},
];