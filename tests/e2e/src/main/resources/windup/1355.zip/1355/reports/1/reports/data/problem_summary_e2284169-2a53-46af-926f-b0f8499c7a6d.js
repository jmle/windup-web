MIGRATION_ISSUES_DETAILS["e2284169-2a53-46af-926f-b0f8499c7a6d"] = [
{description: "<p>This is a WebLogic proprietary type (<code>weblogic.websocket.WebSocketAdapter<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-01000", issueName: "WebLogic proprietary type reference",
problemSummaryID: "e2284169-2a53-46af-926f-b0f8499c7a6d", files: [
{l:"<a class='' href='ChatEndpoint_java.html?project=6459904'>org.sample.chat.ChatEndpoint<\/a>", oc:"3"},
], resourceLinks: [
]},
{description: "<p>This is a WebLogic proprietary type (<code>weblogic.websocket.WSHandshakeRequest<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-01000", issueName: "WebLogic proprietary type reference",
problemSummaryID: "e2284169-2a53-46af-926f-b0f8499c7a6d", files: [
{l:"<a class='' href='ChatEndpoint_java.html?project=6459904'>org.sample.chat.ChatEndpoint<\/a>", oc:"2"},
], resourceLinks: [
]},
{description: "<p>This is a WebLogic proprietary type (<code>weblogic.websocket.WebSocketConnection<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-01000", issueName: "WebLogic proprietary type reference",
problemSummaryID: "e2284169-2a53-46af-926f-b0f8499c7a6d", files: [
{l:"<a class='' href='ChatEndpoint_java.html?project=6459904'>org.sample.chat.ChatEndpoint<\/a>", oc:"5"},
], resourceLinks: [
]},
{description: "<p>This is a WebLogic proprietary type (<code>weblogic.websocket.WebSocketConnection.send(java.lang.String)<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-01000", issueName: "WebLogic proprietary type reference",
problemSummaryID: "e2284169-2a53-46af-926f-b0f8499c7a6d", files: [
{l:"<a class='' href='ChatEndpoint_java.html?project=6459904'>org.sample.chat.ChatEndpoint<\/a>", oc:"3"},
], resourceLinks: [
]},
{description: "<p>This is a WebLogic proprietary type (<code>weblogic.websocket.annotation.WebSocket<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-01000", issueName: "WebLogic proprietary type reference",
problemSummaryID: "e2284169-2a53-46af-926f-b0f8499c7a6d", files: [
{l:"<a class='' href='ChatEndpoint_java.html?project=6459904'>org.sample.chat.ChatEndpoint<\/a>", oc:"2"},
], resourceLinks: [
]},
{description: "<p>This is a WebLogic proprietary type (<code>weblogic.websocket.WSHandshakeResponse<\/code>) and needs to be migrated to a compatible API. There is currently no detailed information about this type.<\/p>", ruleID: "weblogic-catchall-01000", issueName: "WebLogic proprietary type reference",
problemSummaryID: "e2284169-2a53-46af-926f-b0f8499c7a6d", files: [
{l:"<a class='' href='ChatEndpoint_java.html?project=6459904'>org.sample.chat.ChatEndpoint<\/a>", oc:"2"},
], resourceLinks: [
]},
];