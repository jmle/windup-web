MIGRATION_ISSUES_DETAILS["26507d46-d766-42cd-83da-71e38ad7c8a3"] = [
{description: "<p>After migration, some of the JMX beans provided by the previous server may not be present anymore. Ensure that the <code>javax.management.ObjectName<\/code> does not need to change for JBoss.<\/p>", ruleID: "environment-dependent-calls-04000", issueName: "JMX MBean object name (javax.management.ObjectName)",
problemSummaryID: "26507d46-d766-42cd-83da-71e38ad7c8a3", files: [
{l:"<a class='' href='WASModuleInspectorPlugin_java.html?project=5838848'>com.googlecode.arit.websphere.WASModuleInspectorPlugin<\/a>", oc:"4"},
{l:"<a class='' href='MBeanScanner_java.html?project=5838848'>com.googlecode.arit.mbeans.MBeanScanner<\/a>", oc:"2"},
], resourceLinks: [
]},
];