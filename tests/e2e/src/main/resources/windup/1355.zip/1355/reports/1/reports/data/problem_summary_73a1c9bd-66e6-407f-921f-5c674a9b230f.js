MIGRATION_ISSUES_DETAILS["73a1c9bd-66e6-407f-921f-5c674a9b230f"] = [
{description: "<p>Maven Project Object Model (POM) File<\/p>", ruleID: "DiscoverMavenProjectsRuleProvider_1", issueName: "Maven POM (pom.xml)",
problemSummaryID: "73a1c9bd-66e6-407f-921f-5c674a9b230f", files: [
{l:"<a class='' href='pom_xml.181.html?project=6459904'>META-INF/maven/com.sun.mail/javax.mail/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.180.html?project=6459904'>pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.179.html?project=6459904'>META-INF/maven/org.sample/chat/pom.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];