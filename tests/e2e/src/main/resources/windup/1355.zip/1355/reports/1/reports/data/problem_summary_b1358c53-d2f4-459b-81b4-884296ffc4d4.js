MIGRATION_ISSUES_DETAILS["b1358c53-d2f4-459b-81b4-884296ffc4d4"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "b1358c53-d2f4-459b-81b4-884296ffc4d4", files: [
{l:"<a class='' href='web_xml.6.html?project=6459904'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];