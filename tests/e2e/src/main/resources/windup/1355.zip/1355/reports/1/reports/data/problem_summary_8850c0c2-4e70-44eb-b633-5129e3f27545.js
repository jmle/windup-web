MIGRATION_ISSUES_DETAILS["8850c0c2-4e70-44eb-b633-5129e3f27545"] = [
{description: "<p>The application embedds a JDBC library.<\/p>", ruleID: "DiscoverEmbeddedJDBCLibraryRuleProvider_1", issueName: "Embedded library - JDBC",
problemSummaryID: "8850c0c2-4e70-44eb-b633-5129e3f27545", files: [
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/ojdbc6.jar", oc:"1"},
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-jdbc-4.0.9.RELEASE.jar", oc:"1"},
{l:"arit-ear-0.8.1-SNAPSHOT.ear/arit.war/WEB-INF/lib/arit-jdbc-0.8.1-SNAPSHOT.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/lib/ojdbc6-11.2.0.3.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/ojdbc6-11.2.0.3.jar", oc:"1"},
], resourceLinks: [
]},
];