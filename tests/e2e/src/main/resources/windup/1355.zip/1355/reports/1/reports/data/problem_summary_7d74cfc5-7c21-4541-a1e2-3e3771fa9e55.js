MIGRATION_ISSUES_DETAILS["7d74cfc5-7c21-4541-a1e2-3e3771fa9e55"] = [
{description: "<p><strong>Hard-coded IP: 2.5.4.5<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='SignedDoc_java.html?project=6211328'>ee.sk.digidoc.SignedDoc<\/a>", oc:"1"},
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.37<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ExtendedKeyUsage_java.html?project=6211328'>iaik.x509.extensions.ExtendedKeyUsage<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.46<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='FreshestCRL_java.html?project=6211328'>iaik.x509.extensions.FreshestCRL<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.23<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='HoldInstructionCode_java.html?project=6211328'>iaik.x509.extensions.HoldInstructionCode<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.16<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='PrivateKeyUsagePeriod_java.html?project=6211328'>iaik.x509.extensions.PrivateKeyUsagePeriod<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.28<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='IssuingDistributionPoint_java.html?project=6211328'>iaik.x509.extensions.IssuingDistributionPoint<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.32<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='CertificatePolicies_java.html?project=6211328'>iaik.x509.extensions.CertificatePolicies<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.19<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='BasicConstraints_java.html?project=6211328'>iaik.x509.extensions.BasicConstraints<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.29<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='CertificateIssuer_java.html?project=6211328'>iaik.x509.extensions.CertificateIssuer<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.27<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='DeltaCRLIndicator_java.html?project=6211328'>iaik.x509.extensions.DeltaCRLIndicator<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.17<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='SubjectAltName_java.html?project=6211328'>iaik.x509.extensions.SubjectAltName<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.18<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='IssuerAltName_java.html?project=6211328'>iaik.x509.extensions.IssuerAltName<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.30<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='NameConstraints_java.html?project=6211328'>iaik.x509.extensions.NameConstraints<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.36<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='PolicyConstraints_java.html?project=6211328'>iaik.x509.extensions.PolicyConstraints<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.24<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='InvalidityDate_java.html?project=6211328'>iaik.x509.extensions.InvalidityDate<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.54<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='InhibitAnyPolicy_java.html?project=6211328'>iaik.x509.extensions.InhibitAnyPolicy<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.14<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='SubjectKeyIdentifier_java.html?project=6211328'>iaik.x509.extensions.SubjectKeyIdentifier<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.3<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.6<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.7<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.8<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.9<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.10<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.11<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.12<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.13<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.16<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.17<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.4<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.42<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.43<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.44<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.45<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.46<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.4.65<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ObjectID_java.html?project=6211328'>iaik.asn1.ObjectID<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.31<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='CRLDistributionPoints_java.html?project=6211328'>iaik.x509.extensions.CRLDistributionPoints<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.33<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='PolicyMappings_java.html?project=6211328'>iaik.x509.extensions.PolicyMappings<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.20<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='CRLNumber_java.html?project=6211328'>iaik.x509.extensions.CRLNumber<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.35<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='AuthorityKeyIdentifier_java.html?project=6211328'>iaik.x509.extensions.AuthorityKeyIdentifier<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.15<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='KeyUsage_java.html?project=6211328'>iaik.x509.extensions.KeyUsage<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.9<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='SubjectDirectoryAttributes_java.html?project=6211328'>iaik.x509.extensions.SubjectDirectoryAttributes<\/a>", oc:"1"},
], resourceLinks: [
]},
{description: "<p><strong>Hard-coded IP: 2.5.29.21<\/strong><\/p><p>When migrating environments, hard-coded IP addresses may need to be modified or eliminated.<\/p>", ruleID: "DiscoverHardcodedIPAddressRuleProvider", issueName: "Hard-coded IP address",
problemSummaryID: "7d74cfc5-7c21-4541-a1e2-3e3771fa9e55", files: [
{l:"<a class='' href='ReasonCode_java.html?project=6211328'>iaik.x509.extensions.ReasonCode<\/a>", oc:"1"},
], resourceLinks: [
]},
];