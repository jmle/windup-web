MIGRATION_ISSUES_DETAILS["7fbe5fb1-e43f-41c9-86aa-ff8e09bae438"] = [
{description: "<p>The application embedds a JDBC library.<\/p>", ruleID: "DiscoverEmbeddedJDBCLibraryRuleProvider_1", issueName: "Embedded library - JDBC",
problemSummaryID: "7fbe5fb1-e43f-41c9-86aa-ff8e09bae438", files: [
{l:"AdministracionEfectivo.ear/lib/ojdbc6-11.2.0.3.jar", oc:"1"},
{l:"AdministracionEfectivo.ear/AdministracionEfectivo-web-0.0.1-SNAPSHOT.war/WEB-INF/lib/ojdbc6-11.2.0.3.jar", oc:"1"},
], resourceLinks: [
]},
];