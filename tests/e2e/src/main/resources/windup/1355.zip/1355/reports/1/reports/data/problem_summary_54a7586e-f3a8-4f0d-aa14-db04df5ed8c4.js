MIGRATION_ISSUES_DETAILS["54a7586e-f3a8-4f0d-aa14-db04df5ed8c4"] = [
{description: "<p>The application embeds a Spring MVC library.<\/p>", ruleID: "mvc-01200", issueName: "Embedded library - Spring MVC",
problemSummaryID: "54a7586e-f3a8-4f0d-aa14-db04df5ed8c4", files: [
{l:"adit-arendus-1.1.24.ear/adit.war/WEB-INF/lib/spring-webmvc-4.0.9.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];