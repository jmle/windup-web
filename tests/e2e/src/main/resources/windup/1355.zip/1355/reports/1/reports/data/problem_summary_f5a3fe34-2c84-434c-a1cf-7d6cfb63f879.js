MIGRATION_ISSUES_DETAILS["f5a3fe34-2c84-434c-a1cf-7d6cfb63f879"] = [
{description: "<p>This XML file could not be parsed.<\/p>", ruleID: "DiscoverXmlFilesRuleProvider_5", issueName: "Unparsable XML File",
problemSummaryID: "f5a3fe34-2c84-434c-a1cf-7d6cfb63f879", files: [
{l:"<a class='' href='recepcionDeposito_xhtml.html?project=6456320'>recepcionDeposito/recepcionDeposito/recepcionDeposito.xhtml<\/a>", oc:"1"},
], resourceLinks: [
]},
];