MIGRATION_ISSUES_DETAILS["a6fa80ac-f59a-4988-a98a-9b7cfd976b99"] = [
{description: "<p>Web Application Deployment Descriptors<\/p>", ruleID: "DiscoverWebXmlRuleProvider_1", issueName: "Web XML",
problemSummaryID: "a6fa80ac-f59a-4988-a98a-9b7cfd976b99", files: [
{l:"<a class='' href='web_xml.2.html?project=6211328'>WEB-INF/web.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];