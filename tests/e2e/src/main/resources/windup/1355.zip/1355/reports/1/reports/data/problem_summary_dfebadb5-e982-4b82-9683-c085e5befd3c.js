MIGRATION_ISSUES_DETAILS["dfebadb5-e982-4b82-9683-c085e5befd3c"] = [
{description: "<p>Maven Project Object Model (POM) File<\/p>", ruleID: "DiscoverMavenProjectsRuleProvider_1", issueName: "Maven POM (pom.xml)",
problemSummaryID: "dfebadb5-e982-4b82-9683-c085e5befd3c", files: [
{l:"<a class='' href='pom_xml.183.html?project=6461440'>META-INF/maven/org.ktest.javaee.study.ejb3-in-action/chapter5-ejb/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.182.html?project=6461440'>META-INF/maven/org.ktest.javaee.study.ejb3-in-action/chapter5-ear/pom.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];