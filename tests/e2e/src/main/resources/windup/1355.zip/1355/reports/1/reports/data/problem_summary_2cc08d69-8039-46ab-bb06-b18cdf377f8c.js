MIGRATION_ISSUES_DETAILS["2cc08d69-8039-46ab-bb06-b18cdf377f8c"] = [
{description: "<p>Maven Project Object Model (POM) File<\/p>", ruleID: "DiscoverMavenProjectsRuleProvider_1", issueName: "Maven POM (pom.xml)",
problemSummaryID: "2cc08d69-8039-46ab-bb06-b18cdf377f8c", files: [
{l:"<a class='' href='pom_xml.22.html?project=6171392'>META-INF/maven/org.apache.commons/commons-lang3/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.20.html?project=6171392'>META-INF/maven/br.com.impacta/buscadorPotenciaisClientesJPA/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.17.html?project=6171392'>META-INF/maven/joda-time/joda-time/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.18.html?project=6171392'>META-INF/maven/br.com.impacta/buscadorPotenciaisClientesEJBClient/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.21.html?project=6171392'>META-INF/maven/br.com.impacta/buscadorPotenciaisClientesVO/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.19.html?project=6171392'>META-INF/maven/com.google.guava/guava/pom.xml<\/a>", oc:"1"},
{l:"<a class='' href='pom_xml.16.html?project=6171392'>META-INF/maven/br.com.impacta/buscadorPotenciaisClientesWS/pom.xml<\/a>", oc:"1"},
], resourceLinks: [
]},
];