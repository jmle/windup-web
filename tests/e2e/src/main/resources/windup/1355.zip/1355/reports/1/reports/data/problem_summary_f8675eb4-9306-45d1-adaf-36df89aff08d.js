MIGRATION_ISSUES_DETAILS["f8675eb4-9306-45d1-adaf-36df89aff08d"] = [
{description: "<p>The application embeds the JUnit framework.<\/p>", ruleID: "embedded-framework-01900", issueName: "Embedded framework - JUnit",
problemSummaryID: "f8675eb4-9306-45d1-adaf-36df89aff08d", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/junit-4.8.1.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/powermock-module-junit4-common-1.4.6.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/powermock-module-junit4-1.4.6.jar", oc:"1"},
], resourceLinks: [
]},
];