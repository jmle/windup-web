MIGRATION_ISSUES_DETAILS["399c0ccf-9fe2-4ca0-857b-5eb9493a25aa"] = [
{description: "<p>The application embeds the Spring framework.<\/p>", ruleID: "embedded-framework-02100", issueName: "Embedded framework - Spring",
problemSummaryID: "399c0ccf-9fe2-4ca0-857b-5eb9493a25aa", files: [
{l:"spring-core-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-expression-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-aop-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-context-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-beans-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-asm-3.0.5.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];