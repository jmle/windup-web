MIGRATION_ISSUES_DETAILS["5be82115-c805-4600-9f1f-5e99bd737f6a"] = [
{description: "<p>The application embeds the Spring framework.<\/p>", ruleID: "embedded-framework-02100", issueName: "Embedded framework - Spring",
problemSummaryID: "5be82115-c805-4600-9f1f-5e99bd737f6a", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-context-support-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-tx-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-context-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-aop-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-jms-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-test-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-aspects-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-expression-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-core-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-beans-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-asm-3.0.7.RELEASE.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/spring-web-3.0.7.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];