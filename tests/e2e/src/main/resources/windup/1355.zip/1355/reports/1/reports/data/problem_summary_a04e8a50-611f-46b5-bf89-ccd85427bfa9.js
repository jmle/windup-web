MIGRATION_ISSUES_DETAILS["a04e8a50-611f-46b5-bf89-ccd85427bfa9"] = [
{description: "<p>The application embeds the Spring framework.<\/p>", ruleID: "embedded-framework-02100", issueName: "Embedded framework - Spring",
problemSummaryID: "a04e8a50-611f-46b5-bf89-ccd85427bfa9", files: [
{l:"spring-core-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-expression-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-aop-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-context-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-beans-3.0.5.RELEASE.jar", oc:"1"},
{l:"arit-ear-0.8.1-SNAPSHOT.ear/arit.war/WEB-INF/lib/spring-web-3.0.5.RELEASE.jar", oc:"1"},
{l:"spring-asm-3.0.5.RELEASE.jar", oc:"1"},
{l:"arit-ear-0.8.1-SNAPSHOT.ear/arit.war/WEB-INF/lib/spring-core-3.0.5.RELEASE.jar", oc:"1"},
{l:"arit-ear-0.8.1-SNAPSHOT.ear/arit.war/WEB-INF/lib/spring-context-3.0.5.RELEASE.jar", oc:"1"},
{l:"arit-ear-0.8.1-SNAPSHOT.ear/arit.war/WEB-INF/lib/spring-asm-3.0.5.RELEASE.jar", oc:"1"},
{l:"arit-ear-0.8.1-SNAPSHOT.ear/arit.war/WEB-INF/lib/spring-aop-3.0.5.RELEASE.jar", oc:"1"},
{l:"arit-ear-0.8.1-SNAPSHOT.ear/arit.war/WEB-INF/lib/spring-expression-3.0.5.RELEASE.jar", oc:"1"},
{l:"arit-ear-0.8.1-SNAPSHOT.ear/arit.war/WEB-INF/lib/spring-beans-3.0.5.RELEASE.jar", oc:"1"},
], resourceLinks: [
]},
];