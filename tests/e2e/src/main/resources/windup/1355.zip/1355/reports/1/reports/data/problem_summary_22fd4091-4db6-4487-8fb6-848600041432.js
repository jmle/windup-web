MIGRATION_ISSUES_DETAILS["22fd4091-4db6-4487-8fb6-848600041432"] = [
{description: "<p>The application embeds the JUnit framework.<\/p>", ruleID: "embedded-framework-01900", issueName: "Embedded framework - JUnit",
problemSummaryID: "22fd4091-4db6-4487-8fb6-848600041432", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/junit-4.8.1.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/powermock-module-junit4-common-1.4.6.jar", oc:"1"},
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/powermock-module-junit4-1.4.6.jar", oc:"1"},
], resourceLinks: [
]},
];