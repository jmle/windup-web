MIGRATION_ISSUES_DETAILS["70d5a856-fd14-4c56-a20b-39cd651fb288"] = [
{description: "<p>The application embeds the Apache Axis framework.<\/p>", ruleID: "embedded-framework-01000", issueName: "Embedded framework - Apache Axis",
problemSummaryID: "70d5a856-fd14-4c56-a20b-39cd651fb288", files: [
{l:"AdditionWithSecurity-EAR-0.01.ear/AdditionWithSecurity-Service-0.01.war/WEB-INF/lib/axis-jaxrpc-1.4.jar", oc:"1"},
], resourceLinks: [
]},
];