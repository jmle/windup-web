MIGRATION_ISSUES_DETAILS["d0c38cdf-9bca-44f3-9776-08ff53b4c39f"] = [
{description: "<p>The JNDI automatically reads the application resource files from all components in the applications\' classpaths. The JNDI then makes the properties from these files available to the service providers.<\/p><p>Please ensure the property values listed in this file are available to JBoss.<\/p>", ruleID: "environment-dependent-calls-03500", issueName: "JNDI properties file",
problemSummaryID: "d0c38cdf-9bca-44f3-9776-08ff53b4c39f", files: [
{l:"<a class='' href='jndi_properties.html?project=6211328'>jndi.properties<\/a>", oc:"1"},
], resourceLinks: [
]},
];